﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Co3.Rest.Dto;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Co3.Rest.JsonConverters
{
    class InboundMailboxConnectionDetailsDtoConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return typeof(InboundMailboxConnectionDetailsDto).IsAssignableFrom(objectType);
        }

        public override object ReadJson(JsonReader reader, Type objectType,
            object existingValue, Newtonsoft.Json.JsonSerializer serializer)
        {
            JObject jo = JObject.Load(reader);

            InboundMailboxConnectionDetailsDto mailbox = null;

            switch (jo["protocol"].ToString())
            {
                case "imap":
                    mailbox = jo.ToObject<InboundMailboxConnectionDetailsImapDto>();
                    break;
                case "exchange":
                    mailbox = jo.ToObject<InboundMailboxConnectionDetailsExchangeDto>();
                    break;
                case "oauth":
                    mailbox = jo.ToObject<InboundMailboxConnectionDetailsOAuthDto>();
                    break;
                default:
                    throw new NotImplementedException();
            }
            return mailbox;
        }

        public override void WriteJson(JsonWriter writer, object value,
                JsonSerializer serializer)
            {


            JObject.FromObject(value).WriteTo(writer);

            /*
                if (value == null)
                {
                    writer.WriteNull();
                    return;
                }

                //IDictionary values = (IDictionary)value;

                writer.WriteStartObject();
                //foreach (var key in values.Keys)
                foreach (var property in value.GetType().GetProperties())
                {
                    writer.WritePropertyName(property.Name);
                    //writer.WriteValue(property.GetValue(value, null));

                    //serializer.Serialize(writer, values[key]);
                    serializer.Serialize(writer, property.GetValue(value, null));
                }
                writer.WriteEndObject();
            */
            }
            
        }
}
