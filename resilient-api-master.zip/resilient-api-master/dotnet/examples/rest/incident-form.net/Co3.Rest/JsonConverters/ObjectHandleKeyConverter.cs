/*
 * Resilient Systems, Inc. ("Resilient") is willing to license software
 * or access to software to the company or entity that will be using or
 * accessing the software and documentation and that you represent as
 * an employee or authorized agent ("you" or "your") only on the condition
 * that you accept all of the terms of this license agreement.
 *
 * The software and documentation within Resilient's Development Kit are
 * copyrighted by and contain confidential information of Resilient. By
 * accessing and/or using this software and documentation, you agree that
 * while you may make derivative works of them, you:
 *
 * 1)  will not use the software and documentation or any derivative
 *     works for anything but your internal business purposes in
 *     conjunction your licensed used of Resilient's software, nor
 * 2)  provide or disclose the software and documentation or any
 *     derivative works to any third party.
 *
 * THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL RESILIENT BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using Co3.Rest.Dto;
using Newtonsoft.Json;

namespace Co3.Rest.JsonConverters
{
    /// <summary>
    /// Converts objects of the type IDictionary&lt;ObjectHandle, T&gt;.
    /// </summary>
    public class ObjectHandleKeyConverter : JsonConverter
    {
        public override void WriteJson(JsonWriter writer, object obj, JsonSerializer serializer)
        {
            IDictionary values = (IDictionary)obj;

            bool isIdsHandleFormat = true;
            foreach (var key in values.Keys)
            {
                isIdsHandleFormat &= string.IsNullOrEmpty(((ObjectHandle)key).Name);
            }

            writer.WriteStartObject();
            foreach (var key in values.Keys)
            {
                ObjectHandle handle = (ObjectHandle)key;
                writer.WritePropertyName(isIdsHandleFormat ? handle.Id.ToString() : handle.Name);
                serializer.Serialize(writer, values[key]);
            }
            writer.WriteEndObject();
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            IDictionary returnValue = (IDictionary)Activator.CreateInstance(objectType);

            Type valueType = GetValueType(objectType);

            if (reader.TokenType != JsonToken.StartObject)
                throw new System.FormatException("Unexpected TokenType while deserializing IDictionary<ObjectHandle, T>");
            
            while (reader.Read())
            {
                if (reader.TokenType == JsonToken.EndObject)
                    break;

                string key = (string)reader.Value;
                ObjectHandle handle = new ObjectHandle();
                int id;
                if (int.TryParse(key, out id))
                    handle.Id = id;
                else
                    handle.Name = key;

                reader.Read();

                if (valueType.IsClass)
                    returnValue.Add(handle, serializer.Deserialize(reader, valueType));
                else
                    returnValue.Add(handle, Convert.ChangeType(reader.Value, valueType));
            }

            return returnValue;
        }

        public override bool CanConvert(Type type)
        {
            return GetIDictionaryType(type) != null;
        }

        /// <summary>
        /// Get IDictionary&lt;ObjectHandle, T&gt; for the given type.
        /// </summary>
        /// <param name="type"></param>
        /// <returns>The type for IDictionary&lt;ObjectHandle, T&gt;, or null if type does not implement it.</returns>
        static Type GetIDictionaryType(Type type)
        {
            Type interfaceType = null;

            // See if IDictionary<,> is implemented by the type
            interfaceType = Array.Find(type.GetInterfaces(), ImplementsIDictionary);

            // If it is not...
            if (interfaceType == null)
            {
                // Check if the type itself is IDictionary<,>
                if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(IDictionary<,>))
                    interfaceType = type;

                // Check the type's base implements IDictionary<,>
                else if (type.BaseType != null)
                    interfaceType = GetIDictionaryType(type.BaseType);
            }

            return interfaceType;
        }

        /// <summary>
        /// Determine if type implements IDictionary&lt;ObjectHandle, T&gt;
        /// </summary>
        /// <returns>True if it's implemented, false otherwise</returns>
        static bool ImplementsIDictionary(Type type)
        {
            return type.IsGenericType
                && type.GetGenericTypeDefinition() == typeof(IDictionary<,>)
                && type.GetGenericArguments()[0] == typeof(ObjectHandle); // IDictionary<ObjectHandle, T>
        }

        /// <summary>
        /// Returns the type T in IDictionary&lt;ObjectHandle, T&gt;
        /// </summary>
        /// <param name="type">The object type that implements IDictionary&lt;ObjectHandle, T&gt;</param>
        /// <returns>The type T or null if type does not implement IDictionary&lt;ObjectHandle, T&gt;</returns>
        static Type GetValueType(Type type)
        {
            Type interfaceType = GetIDictionaryType(type);
            return interfaceType == null ? null : interfaceType.GetGenericArguments()[1];
        }
    }
}