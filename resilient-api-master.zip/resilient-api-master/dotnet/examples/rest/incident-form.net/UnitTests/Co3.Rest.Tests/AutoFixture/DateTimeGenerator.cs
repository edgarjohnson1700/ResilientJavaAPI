﻿using System;
using Ploeh.AutoFixture.Kernel;

namespace Co3.Rest.AutoFixture
{
    /// <summary>
    /// Create a DateTime without fractional milliseconds
    /// </summary>
    public class DateTimeGenerator : ISpecimenBuilder
    {
        const int Range = 10000;
        static readonly Type s_type = typeof(DateTime);

        public object Create(object request, ISpecimenContext context)
        {
            if (request as Type != s_type)
                return new NoSpecimen();
            
            DateTime time = DateTime.UtcNow.AddSeconds(Generator.Generate<int>());
            time = new DateTime(time.Year, time.Month, time.Day, time.Hour, time.Minute, time.Second, time.Millisecond, time.Kind);
            return time;
        }
    }
}
