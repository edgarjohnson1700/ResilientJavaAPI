﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Co3.Rest.Dto;
using Ploeh.AutoFixture.Kernel;

namespace Co3.Rest.AutoFixture
{
    class InboundMailboxConnectionDetailsDtoGenerator : ISpecimenBuilder
    {
        const int Range = 10000;
        static readonly Type s_type = typeof(InboundMailboxConnectionDetailsExchangeDto);

        public object Create(object request, ISpecimenContext context)
        {
            if (!typeof(InboundMailboxConnectionDetailsDto).IsAssignableFrom(request as Type))
                return new NoSpecimen();


            Type requestType = request as Type;
            switch (requestType.Name)
            {
                case "InboundMailboxConnectionDetailsExchangeDto":
                    return new InboundMailboxConnectionDetailsExchangeDto
                    {
                        Protocol = "exchange",
                        EmailAddress = Generator.Generate<string>(),
                        Password = Generator.Generate<string>(),
                        SourceFolder = Generator.Generate<string>(),
                        DestinationFolder = Generator.Generate<string>(),
                        Proxy = Generator.Generate<ProxyDto>(),
                        Endpoint = Generator.Generate<string>(),
                    };
                case "InboundMailboxConnectionDetailsOAuthDto":
                    return new InboundMailboxConnectionDetailsOAuthDto
                    {
                        Protocol = "oauth",
                        EmailAddress = Generator.Generate<string>(),
                        Password = Generator.Generate<string>(),
                        SourceFolder = Generator.Generate<string>(),
                        DestinationFolder = Generator.Generate<string>(),
                        Proxy = Generator.Generate<ProxyDto>(),
                        Endpoint = Generator.Generate<string>(),
                        ClientId = Generator.Generate<string>(),
                        TenantId = Generator.Generate<string>(),
                        ClientSecret = Generator.Generate<string>(),
                        RefreshToken = Generator.Generate<string>(),
                        AccessGranted = Generator.Generate<bool>(),
                    };
                case "InboundMailboxConnectionDetailsImapDto":
                    return new InboundMailboxConnectionDetailsImapDto
                    {
                        Protocol = "imap",
                        EmailAddress = Generator.Generate<string>(),
                        Password = Generator.Generate<string>(),
                        SourceFolder = Generator.Generate<string>(),
                        DestinationFolder = Generator.Generate<string>(),
                        Proxy = Generator.Generate<ProxyDto>(),
                        HostName = Generator.Generate<string>(),
                        Port = Generator.Generate<int>(),
                        EncryptionMethod = Generator.Generate<EncryptionMethodType>(),
                    };
                default:
                    return new NoSpecimen();

            }
        }
    }
}
