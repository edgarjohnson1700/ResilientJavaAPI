﻿using System;
using Co3.Rest.Dto;
using Ploeh.AutoFixture.Kernel;

namespace Co3.Rest.AutoFixture
{
    class InboundMailboxDtoGenerator : ISpecimenBuilder
    {
        static readonly Type s_type = typeof(InboundMailboxDto);

        public object Create(object request, ISpecimenContext context)
        {
            if (request as Type != s_type)
                return new NoSpecimen();

            return new InboundMailboxDto
            {
                Version = Generator.Generate<int>(),
                Uuid = Generator.Generate<Guid>(),
                ExportKey = Generator.Generate<string>(),
                DisplayName = Generator.Generate<string>(),
                Description = Generator.Generate<string>(),

                // InboundMailboxDto.ConnectionDetails returns an abstract class, this fails on class generation, 
                // so we are going to return an object that extends the class InboundMailboxDto
                //ConnectionDetails = Generator.Generate<InboundMailboxConnectionDetailsExchangeDto>(),
                ConnectionDetails = new InboundMailboxConnectionDetailsExchangeDto
                {
                    Protocol = "exchange",
                    EmailAddress = Generator.Generate<string>(),
                    Password = Generator.Generate<string>(),
                    SourceFolder = Generator.Generate<string>(),
                    DestinationFolder = Generator.Generate<string>(),
                    Proxy = Generator.Generate<ProxyDto>(),
                    Endpoint = Generator.Generate<string>(),
                },
        };
        }
    }
}
