﻿/*
 * Resilient Systems, Inc. ("Resilient") is willing to license software
 * or access to software to the company or entity that will be using or
 * accessing the software and documentation and that you represent as
 * an employee or authorized agent ("you" or "your") only on the condition
 * that you accept all of the terms of this license agreement.
 *
 * The software and documentation within Resilient's Development Kit are
 * copyrighted by and contain confidential information of Resilient. By
 * accessing and/or using this software and documentation, you agree that
 * while you may make derivative works of them, you:
 *
 * 1)  will not use the software and documentation or any derivative
 *     works for anything but your internal business purposes in
 *     conjunction your licensed used of Resilient's software, nor
 * 2)  provide or disclose the software and documentation or any
 *     derivative works to any third party.
 *
 * THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL RESILIENT BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Collections.Specialized;
using Co3.Rest.Dto;
using Newtonsoft.Json;

namespace Co3.Rest.Endpoints
{
    /// <summary>
    /// Dummy class used by unit tests to access to protected members in RestEndpoint.
    /// </summary>
    public class DummyRestEndpoint : RestEndpoint
    {
        public DummyRestEndpoint(UserSessionDto session) : base(null)
        {
            m_session = session;
        }

        public T Get<T>(string endpointUrl)
        {
            return HttpGet<T>(endpointUrl);
        }

        public T Post<T>(string endPointUrl, object postData)
        {
            return HttpPost<T>(endPointUrl, postData);
        }

        public T Post<T>(string endPointUrl, NameValueCollection parameters, object postData)
        {
            return HttpPost<T>(endPointUrl, parameters, postData);
        }

        public T Put<T>(string endPointUrl, NameValueCollection parameters, object postData)
        {
            return HttpPut<T>(endPointUrl, parameters, postData);
        }

        public T Delete<T>(string endPointUrl)
        {
            return HttpDelete<T>(endPointUrl);
        }

        public string Serialize(object obj)
        {
            return ToJson(obj);
        }

        public T Deserialize<T>(string json)
        {
            return FromJson<T>(json);
        }

        public object Deserialize(string json, Type type)
        {
            return JsonConvert.DeserializeObject(json, type, m_jsonSerializerSettings);
        }
    }
}
