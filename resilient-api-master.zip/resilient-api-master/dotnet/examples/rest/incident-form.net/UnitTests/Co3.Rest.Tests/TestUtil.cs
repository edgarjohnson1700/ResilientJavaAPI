﻿/*
 * Resilient Systems, Inc. ("Resilient") is willing to license software
 * or access to software to the company or entity that will be using or
 * accessing the software and documentation and that you represent as
 * an employee or authorized agent ("you" or "your") only on the condition
 * that you accept all of the terms of this license agreement.
 *
 * The software and documentation within Resilient's Development Kit are
 * copyrighted by and contain confidential information of Resilient. By
 * accessing and/or using this software and documentation, you agree that
 * while you may make derivative works of them, you:
 *
 * 1)  will not use the software and documentation or any derivative
 *     works for anything but your internal business purposes in
 *     conjunction your licensed used of Resilient's software, nor
 * 2)  provide or disclose the software and documentation or any
 *     derivative works to any third party.
 *
 * THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL RESILIENT BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Collections.Generic;
using Co3.Rest.CompareNetComparers;
using Co3.Rest.Dto;
using Co3.Rest.Endpoints;
using KellermanSoftware.CompareNetObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Co3.Rest
{
    public static class TestUtil
    {
        public static CompareLogic CreateComparer()
        {
            ComparisonConfig config = new ComparisonConfig();
            config.CustomComparers.Add(new ObjectHandlerComparer());
            config.CustomComparers.Add(new JObjectComparer());
            config.CustomComparers.Add(new DateTimeComparer());
            config.CustomComparers.Add(new IpAddressComparer());

            CompareLogic comparer = new CompareLogic(config);
            return comparer;
        }

        public static void Compare(object expected, object actual)
        {
            ComparisonResult result = CreateComparer().Compare(expected, actual);
            Assert.IsTrue(result.AreEqual, expected.GetType().FullName + ": " + result.DifferencesString);
        }

        public static void VerifyJsonSerialization(object expected)
        {
            DummyRestEndpoint endpoint = new DummyRestEndpoint(null);
            string json = endpoint.Serialize(expected);
            object actual = endpoint.Deserialize(json, expected.GetType());
            Compare(expected, actual);
        }

        /// <summary>
        /// Get the searchType if type implements its.
        /// </summary>
        /// <param name="type">The type in which to search for searchType</param>
        /// <param name="searchType">The searchType to search for</param>
        /// <returns>The searchType if it exists. Otherwise null.</returns>
        public static Type GetImplementedType(Type type, Type searchType)
        {
            Type interfaceType = null;

            // See if searchType is inherited by the type
            interfaceType = Array.Find(type.GetInterfaces(), t => ImplementsType(t, searchType));

            // If it is not...
            if (interfaceType == null)
            {
                // Check if the type itself is IDictionary<,>
                if (type.IsGenericType && type.GetGenericTypeDefinition() == searchType)
                    interfaceType = type;

                // Check the type's base implements searchType
                else if (type.BaseType != null)
                    interfaceType = GetImplementedType(type.BaseType, searchType);
            }

            return interfaceType;
        }

        /// <summary>
        /// Determine if type implements searchType.
        /// </summary>
        /// <returns>True if it's implemented, false otherwise</returns>
        public static bool ImplementsType(Type type, Type searchType)
        {
            if (type.IsGenericType != searchType.IsGenericType)
                return false;

            return type.IsGenericType
                ? type.GetGenericTypeDefinition() == searchType
                : type == searchType;
        }
    }
}
