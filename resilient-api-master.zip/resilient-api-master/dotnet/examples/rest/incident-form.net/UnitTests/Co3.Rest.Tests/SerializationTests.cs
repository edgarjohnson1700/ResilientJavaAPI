﻿/*
 * Resilient Systems, Inc. ("Resilient") is willing to license software
 * or access to software to the company or entity that will be using or
 * accessing the software and documentation and that you represent as
 * an employee or authorized agent ("you" or "your") only on the condition
 * that you accept all of the terms of this license agreement.
 *
 * The software and documentation within Resilient's Development Kit are
 * copyrighted by and contain confidential information of Resilient. By
 * accessing and/or using this software and documentation, you agree that
 * while you may make derivative works of them, you:
 *
 * 1)  will not use the software and documentation or any derivative
 *     works for anything but your internal business purposes in
 *     conjunction your licensed used of Resilient's software, nor
 * 2)  provide or disclose the software and documentation or any
 *     derivative works to any third party.
 *
 * THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL RESILIENT BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Co3.Rest.AutoFixture;
using Co3.Rest.Dto;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Co3.Rest
{
    /// <summary>
    /// Tests to verify the DTOs can be serialized and deserialized to the original DTO object.
    /// </summary>
    [TestClass]
    public class SerializationTests
    {
        [TestMethod]
        public void TestScriptMetadataDtoSerialization()
        {
            ScriptMetadataDto dto = new ScriptMetadataDto
            {
                Keywords = Generator.Generate<List<ScriptMetadataKeywordDto>>(),
                Snippets = Generator.Generate<List<ScriptMetadataSnippetDto>>(),
                Mappings = new Dictionary<string, ScriptMetadataDto>()
            };

            dto.Mappings.Add(Generator.Generate<string>(),
                new ScriptMetadataDto
                {
                    Keywords = Generator.Generate<List<ScriptMetadataKeywordDto>>(),
                    Snippets = Generator.Generate<List<ScriptMetadataSnippetDto>>(),
                    Mappings = new Dictionary<string, ScriptMetadataDto>()
                });
     
            TestUtil.VerifyJsonSerialization(dto);
        }

        [TestMethod]
        public void TestListContainerDtoSerialization()
        {
            ListContainerDto<IncidentDto> incidents = new ListContainerDto<IncidentDto>
            {
                Entities = new List<IncidentDto>
                {
                    (IncidentDto)Generator.Generate(typeof(IncidentDto)),
                    (IncidentDto)Generator.Generate(typeof(IncidentDto)),
                    (IncidentDto)Generator.Generate(typeof(IncidentDto)),
                }
            };

            TestUtil.VerifyJsonSerialization(incidents);
        }

        [TestMethod]
        public void TestDtoSerialization()
        {
            AssemblyName assembly = Assembly.GetExecutingAssembly().GetReferencedAssemblies().SingleOrDefault(a => a.Name.Equals("Co3.Rest"));
            if (assembly != null)
            {
                List<Type> vecIgnoredTypes = new List<Type>
                {
                    // AutoFixture has trouble populating ScriptMetadataDto
                    // so we'll test it separately.
                    typeof(ScriptMetadataDto),

                    // ListContainerDto is generic and can't be instantiated on its own.
                    typeof(ListContainerDto<>)
                };

                foreach (Type type in Assembly.Load(assembly).GetTypes()
                    .Where(t => t.IsClass && t.Namespace.EndsWith(".Dto") && !t.IsAbstract))
                {
                    if (vecIgnoredTypes.Contains(type))
                        System.Diagnostics.Debug.WriteLine("Skipping " + type.FullName);
                    else
                    {
                        System.Diagnostics.Debug.WriteLine("Serializing " + type.FullName);

                        object dto = Generator.Generate(type);
                        TestUtil.VerifyJsonSerialization(dto);
                    }
                }
            }
        }
        
        // In the production code, some maps are defined with "object" as the key, which
        // cannot be properly handled by Json.net. This test verifies no such map exists.
        [TestMethod]
        public void TestMapKeysAreNonObjects()
        {
            AssemblyName assembly = Assembly.GetExecutingAssembly().GetReferencedAssemblies().SingleOrDefault(a => a.Name.Equals("Co3.Rest"));
            if (assembly != null)
            {
                foreach (Type type in Assembly.Load(assembly).GetTypes()
                    .Where(t => t.IsClass && t.Namespace.EndsWith(".Dto") && !t.IsAbstract))
                {

                    foreach (PropertyInfo property in type.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                    {
                        Type propertyType = property.PropertyType;
                        if (!propertyType.IsGenericType)
                            continue;

                        Type interfaceType = TestUtil.GetImplementedType(propertyType, typeof(IDictionary<,>));
                        if (interfaceType == null)
                            continue;

                        Assert.AreNotEqual(typeof(object), interfaceType.GetGenericArguments()[0],
                            "IDictionary<,> cannot have object as the key");
                    }   
                }
            }
        }
    }
}
