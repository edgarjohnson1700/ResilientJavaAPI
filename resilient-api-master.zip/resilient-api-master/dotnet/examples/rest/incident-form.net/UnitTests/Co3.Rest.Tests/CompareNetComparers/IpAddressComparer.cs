﻿using System.Net;

namespace Co3.Rest.CompareNetComparers
{
    public class IpAddressComparer : GenericComparer<IPAddress>
    {
        public IpAddressComparer() : base()
        {
        }

        protected override int Compare(IPAddress object1, IPAddress object2)
        {
            byte[] bytes1 = object1.GetAddressBytes();
            byte[] bytes2 = object2.GetAddressBytes();

            int result = bytes1.Length.CompareTo(bytes2.Length);
            if (result != 0)
                return result;

            result = 0;
            for (int i = 0; i < bytes1.Length && result == 0; ++i)
                result = bytes1[i].CompareTo(bytes2[i]);

            return result;
        }
    }
}
