﻿/*
 * Resilient Systems, Inc. ("Resilient") is willing to license software
 * or access to software to the company or entity that will be using or
 * accessing the software and documentation and that you represent as
 * an employee or authorized agent ("you" or "your") only on the condition
 * that you accept all of the terms of this license agreement.
 *
 * The software and documentation within Resilient's Development Kit are
 * copyrighted by and contain confidential information of Resilient. By
 * accessing and/or using this software and documentation, you agree that
 * while you may make derivative works of them, you:
 *
 * 1)  will not use the software and documentation or any derivative
 *     works for anything but your internal business purposes in
 *     conjunction your licensed used of Resilient's software, nor
 * 2)  provide or disclose the software and documentation or any
 *     derivative works to any third party.
 *
 * THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL RESILIENT BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using Co3.Rest.AutoFixture;
using Co3.Rest.Dto;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Co3.Rest.JsonConverters
{
    [TestClass]
    public class ObjectHandleKeyConverterTests
    {
        [TestMethod]
        public void TestSerialization()
        {
            DataTableRowDataDto dto = new DataTableRowDataDto
            {
                Cells = new Dictionary<ObjectHandle, DataTableCellDataDto>()
            };

            ObjectHandle handle = new ObjectHandle
            {
                Name = "one_two_three"
            };

            dto.Cells.Add(handle, new DataTableCellDataDto
            {
                Id = new ObjectHandle { Id = (long)1 },
                RowId = 2,
                Value = "value"
            });

            TestUtil.VerifyJsonSerialization(dto);
        }

        [TestMethod]
        public void TestDictionary()
        {
            CreateAndConvert<Dictionary<ObjectHandle, int>>();
        }

        [TestMethod]
        public void TestSortedListSubclass()
        {
            CreateAndConvert<SortedListSubclass>();
        }

        [TestMethod]
        public void TestDataTableDataDto()
        {
            Dictionary<ObjectHandle, DataTableDataDto> dataTableData
                = new Dictionary<ObjectHandle, DataTableDataDto>();

            for (int i = 0; i < 3; ++i)
            {
                dataTableData.Add(Generator.Generate<ObjectHandle>(), Generator.Generate<DataTableDataDto>());
            }

            TestUtil.VerifyJsonSerialization(dataTableData);
        }

        [TestMethod]
        public void TestDataTableDataDto2()
        {
            Dictionary<ObjectHandle, DataTableDataDto> dataTableData
                = new Dictionary<ObjectHandle, DataTableDataDto>();

            for (int i = 0; i < 3; ++i)
            {
                dataTableData.Add(new ObjectHandle { Id = 1005 + i }, Generator.Generate<DataTableDataDto>());
            }

            TestUtil.VerifyJsonSerialization(dataTableData);
        }

        [TestMethod]
        public void TestConvertibleType()
        {
            Type[] types = {
                typeof(IDictionary<ObjectHandle, int>),
                typeof(Dictionary<ObjectHandle, int>),
                typeof(SortedList<ObjectHandle, int>),
                typeof(SortedListSubclass)
            };

            ObjectHandleKeyConverter converter = new ObjectHandleKeyConverter();

            foreach (Type type in types)
            {
                Assert.IsTrue(converter.CanConvert(type));
            }
        }

        private void CreateAndConvert<T>() where T : IDictionary, new()
        {
            T obj = new T();
            obj.Add(new ObjectHandle { Name = Guid.NewGuid().ToString() }, 1);
            obj.Add(new ObjectHandle { Name = Guid.NewGuid().ToString() }, 2);
            obj.Add(new ObjectHandle { Name = Guid.NewGuid().ToString() }, 3);

            TestUtil.VerifyJsonSerialization(obj);
        }

        #region SortedList derived class to test serialization
        class SortedListSubclass : SortedList<ObjectHandle, int>
        {
            public SortedListSubclass() : base(new CustomComparer())
            {
            }

            class CustomComparer : IComparer<ObjectHandle>
            {
                public int Compare(ObjectHandle x, ObjectHandle y)
                {
                    if (x.Id == null && y.Id == null)
                        return String.Compare(x.Name, y.Name);
                    else if (x.Id == null)
                        return -1;
                    else if (y.Id == null)
                        return 1;
                    else
                        return String.Compare(x.Id.ToString(), y.Id.ToString());
                }
            }
        }
        #endregion
    }
}
