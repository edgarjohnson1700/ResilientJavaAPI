# Introduction

The public Resilient APIs are at [https://github.com/IBMResilient/](https://github.com/IBMResilient/).

This project contains additional materials for the Java and C# APIs.

The following is the top level directory structure:

 Directory  | Description
 ---------- | -----------
 dotnet     | Microsoft .NET REST API examples
 java       | Java REST API and Action Module examples
 weburl     | Web URL examples


